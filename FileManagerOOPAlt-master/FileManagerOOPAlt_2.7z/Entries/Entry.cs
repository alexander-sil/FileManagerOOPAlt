﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManagerOOPAlt.Entries
{
    public abstract class Entry
    {
        public abstract FileSystemInfo Reference { get; set; }

        public abstract string Name { get; set; }

        public abstract FileAttributes Attributes { get; set; }

        public abstract DateTime LastWriteTime { get; set; }

        public abstract DateTime CreationTime { get; set; }

        public override string ToString()
        {
            return this.Name;
        }
    }
}
