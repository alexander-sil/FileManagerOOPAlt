﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManagerOOPAlt.Entries
{
    public class FileEntry : Entry
    {
        public FileEntry(FileInfo info)
        {
            Reference = info;

            Size = info.Length;

            Name = info.FullName;

            Extension = info.Extension;

            Attributes = info.Attributes;

            LastWriteTime = info.LastWriteTime;

            CreationTime = info.CreationTime;
        }

        public override FileSystemInfo Reference { get; set; }

        public override string Name { get; set; }

        public long Size { get; set; }

        public string Extension { get; set; }

        public override FileAttributes Attributes { get; set; }

        public override DateTime LastWriteTime { get; set; }

        public override DateTime CreationTime { get; set; }

    }
}
