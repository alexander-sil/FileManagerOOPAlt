﻿using FileManagerOOPAlt.Logic;
using System;
using Terminal.Gui;

namespace FileManagerOOPAlt
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                WindowLogic.Execute();
            } catch (Exception e)
            {
                MessageBox.Query("Error", e.Message, "Ok");
            } 
        }
    }
}