﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using FileManagerOOPAlt.Entries;
using Terminal.Gui;

namespace FileManagerOOPAlt.Logic
{
    public class MainLogic
    {
        private static List<Entry> _View = new List<Entry>();

        public static List<Entry> View => _View;

        private static DirectoryInfo _CurrentDir = new DirectoryInfo(@"C:\");

        public static DirectoryInfo CurrentDir => _CurrentDir;

        private static Dictionary<string, List<Entry>> _Entries = new Dictionary<string, List<Entry>>();

        private static void FillEntries(string dir)
        {
            DirectoryInfo[] dirs = _CurrentDir.EnumerateDirectories("*", new EnumerationOptions() { IgnoreInaccessible = true, RecurseSubdirectories = false }).ToArray();
            FileInfo[] files = _CurrentDir.EnumerateFiles("*.*", new EnumerationOptions() { IgnoreInaccessible = true, RecurseSubdirectories = false }).ToArray();


            List<Entry> temp = new List<Entry>();

            foreach (DirectoryInfo j in dirs)
            {
                 temp.Add(new DirectoryEntry(j));
            }

            foreach (FileInfo i in files)
            {
                 temp.Add(new FileEntry(i));
            }

            _Entries.Add(dir, temp);
            
        }

        public static void Execute()
        {

            Redraw(new DirectoryInfo(_CurrentDir.FullName));
        }
        
        private static void Redraw(DirectoryInfo dir)
        {
            _View.Clear();

            
            if (!_Entries.ContainsKey(dir.FullName)) {
                FillEntries(dir.FullName);
                _View.AddRange(_Entries[dir.FullName]);
            }
            else
            {
                _View.AddRange(_Entries[dir.FullName]);
            }

            WindowLogic.fileList.MoveEnd();
            WindowLogic.fileList.MoveHome();
        }

        public static void NonSelectiveRedraw(DirectoryInfo dir)
        {
            _View.Clear();
            
            
            _Entries.Remove(dir.FullName);

            FillEntries(dir.FullName);
            _View.AddRange(_Entries[dir.FullName]);

            WindowLogic.fileList.MoveEnd();
            WindowLogic.fileList.MoveHome();
        }

        public static void GoUp()
        {
            try
            {
                string needle = _CurrentDir.Name;
                string hstack = _CurrentDir.FullName;

                GoTop();
                if (hstack != _CurrentDir.Root.FullName)
                {

                    string newPath = hstack.Remove(hstack.LastIndexOf(needle));

                    Directory.SetCurrentDirectory(newPath);
                    _CurrentDir = new DirectoryInfo(newPath);

                    Redraw(_CurrentDir);
                    WindowLogic.fileList.SetFocus();
                } 
                else
                {
                    GoTop();
                }
            } catch {
                MessageBox.Query("", "The specified folder has no parent directory", "OK");
            }
        }

        public static void GoTop()
        {
            DirectoryInfo? root = _CurrentDir.Root;
            Directory.SetCurrentDirectory(root.FullName);
            Redraw(root);
            WindowLogic.fileList.SetFocus();  
        }

        public static void Highlight(View.MouseEventArgs e)
        {
            WindowLogic.goUpButton.SetFocus();
        }

        public static void Deactivate(View.MouseEventArgs e)
        {
            WindowLogic.fileList.SetFocus();
        }

        public static void ChangeDir(ListViewItemEventArgs e)
        {

            if (e.Value.GetType() == typeof(DirectoryEntry))
            {
                var answer = MessageBox.Query("Action", "Select the desired action to perform: ", "Show info", "Navigate", "Rename", "Move", "Copy", "Delete");

                if (answer == 0)
                {
                    ActionLogic.ShowInfo((DirectoryEntry)e.Value);
                }
                else if (answer == 1)
                {
                    try
                    {
                        _CurrentDir = (DirectoryInfo)((DirectoryEntry)e.Value).Reference;

                        Redraw((DirectoryInfo)((DirectoryEntry)e.Value).Reference);

                        Directory.SetCurrentDirectory(_CurrentDir.FullName);

                    }
                    catch (UnauthorizedAccessException)
                    {
                        MessageBox.Query("", "Access error", "OK");
                    }
                    catch (Exception)
                    {
                        MessageBox.Query("", "Unidentified error", "OK");
                    }
                }
                else if (answer == 2)
                {
                    ActionLogic.Rename((DirectoryEntry)e.Value);

                } else if (answer == 3)
                {
                    ActionLogic.MoveDir((DirectoryEntry)e.Value);

                } else if (answer == 4)
                {
                    ActionLogic.CopyDir((DirectoryEntry)e.Value);

                }
                else if (answer == 5)
                {
                    int x = MessageBox.Query("Confirmation", "Are you sure you want to delete this directory?", "Yes", "No");

                    if (x == 0)
                    {
                        DirectoryLogic.Delete(((DirectoryEntry)e.Value).Reference.FullName);
                    }

                }
            }
            else if (e.Value.GetType() == typeof(FileEntry))
            {
                var answer = MessageBox.Query("Action", "Select the desired action to perform: ", "Show info", "Rename", "Move", "Copy", "Delete");

                if (answer == 0)
                {
                    ActionLogic.ShowInfo((FileEntry)e.Value);
                } 
                else if (answer == 1)
                {
                    ActionLogic.Rename((FileEntry)e.Value);
                }
                else if (answer == 2)
                {
                    ActionLogic.Move((FileEntry)e.Value);
                }
                else if (answer == 3)
                {
                    ActionLogic.Copy((FileEntry)e.Value);
                }
                else if (answer == 4)
                {
                    int x = MessageBox.Query("Confirmation", "Are you sure you want to delete this file?", "Yes", "No");

                    if (x == 0)
                        FileLogic.Delete(((FileEntry)e.Value).Reference.FullName);
                }
            }


            Redraw(_CurrentDir);

            WindowLogic.fileList.SetFocus();




        }
    }
}
