﻿using System;
using Terminal.Gui;

namespace FileManagerOOPAlt
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DriverClass.Run();

        }
    }
}