﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terminal.Gui;

namespace FileManagerOOPAlt.Logic
{
    public class WindowLogic
    {
        public static Toplevel top = Application.Top;

        public static ListView fileList = new ListView(new Rect(1, 2, Console.WindowWidth - 2, Console.WindowHeight - 3), ObjectClass.mainLogic.entries);

        public static Button goUpButton = new Button("Back");

        public void Execute()
        {
            Console.Title = "FileManagerOOP";
            Application.Init();



            Window window = new Window("FileManagerOOP")
            {
                X = 0,
                Y = 1,

                Width = Dim.Fill(),
                Height = Dim.Fill()
            };

            MenuBarItem[] menu = new MenuBarItem[] { new MenuBarItem("_Tools", new MenuItem[] {
                  new MenuItem("New File", "", null, () => true),
                  new MenuItem("New Directory", "", null, () => true)

              }) };

            top.Add(new MenuBar(menu));

            

            

            fileList.OpenSelectedItem += ObjectClass.mainLogic.ChangeDir;

            goUpButton.MouseClick += ObjectClass.mainLogic.GoUp;

            window.Add(fileList);

            window.Add(goUpButton);

            top.Add(window);


            Application.Run();

        }


    }
}
