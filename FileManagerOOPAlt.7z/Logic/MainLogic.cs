﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileManagerOOPAlt.Entries;
using Terminal.Gui;

namespace FileManagerOOPAlt.Logic
{
    public class MainLogic
    {
        private static string _CurrentDir = @"C:\";

        public List<Entry> entries = new List<Entry>();



        private void FillEntries()
        {
            DirectoryInfo[] dirs = new DirectoryInfo(_CurrentDir).EnumerateDirectories("*", new EnumerationOptions() { IgnoreInaccessible = true, RecurseSubdirectories = false }).ToArray();
            FileInfo[] files = new DirectoryInfo(_CurrentDir).EnumerateFiles("*.*", new EnumerationOptions() { IgnoreInaccessible = true, RecurseSubdirectories = false }).ToArray();

            foreach (DirectoryInfo j in dirs)
            {
                entries.Add(new DirectoryEntry(j));
            }

            foreach (FileInfo i in files)
            {  
                entries.Add(new FileEntry(i));
            }

        }

        public MainLogic()
        {

            Redraw();
        }
        
        private void Redraw()
        {
            entries.Clear();
            Directory.SetCurrentDirectory(_CurrentDir);

            FillEntries();
        }

        public void ChangeDir(ListViewItemEventArgs e)
        {
            if (e.Value.GetType() != typeof(DirectoryEntry))
                MessageBox.Query("", "Not a directory", "OK");
            else
                _CurrentDir = ((DirectoryEntry)e.Value).Reference.FullName;
                WindowLogic.fileList.MoveHome();
            Redraw();
           
        }

        public void GoUp()
        {
            try
            {    
                 Directory.SetCurrentDirectory(_CurrentDir + @"\..");
                 entries.Clear();
                 FillEntries();

            } catch
            {
                MessageBox.Query("Error", "This folder does not have a parent directory", "OK");
            }
        }
    }
}
