﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManagerOOPAlt.Logic
{
    public class DirectoryLogic
    {

        public void Create(string dir)
        {
            Directory.CreateDirectory(Path.GetFullPath(dir));
        }

        public long GetSize(string param)
        {
            long length = 0L;

            var dir = new DirectoryInfo(Path.GetFullPath(param));

            DirectoryInfo[] dirs = dir.GetDirectories("*", new EnumerationOptions() { IgnoreInaccessible = true });

            foreach (FileInfo file in dir.GetFiles("*.*", new EnumerationOptions() { IgnoreInaccessible = true }))
            {
                length += file.Length;
            }

            foreach (DirectoryInfo subDir in dirs)
            {
                GetSize(subDir.FullName);
            }

            return length;
        }

        public void Copy(string sourceDir, string destDir)
        {
            var dir = new DirectoryInfo(sourceDir);

            DirectoryInfo[] dirs = dir.EnumerateDirectories("*", new EnumerationOptions() { IgnoreInaccessible = true }).ToArray();


            Directory.CreateDirectory(destDir);

            foreach (FileInfo file in dir.EnumerateFiles("*.*", new EnumerationOptions() { IgnoreInaccessible = true }))
            {
                string targetFilePath = Path.Combine(destDir, file.Name);
                file.CopyTo(targetFilePath);
            }

            foreach (DirectoryInfo subDir in dirs)
            {
                string newDestinationDir = Path.Combine(destDir, subDir.Name);
                Copy(sourceDir, newDestinationDir);
            }

        }

        public void Delete(string dir)
        {
            Directory.Delete(Path.GetFullPath(dir), true);
        }

        public void Rename(string name1, string name2)
        {
            Directory.Move(Path.GetFullPath(name1), Path.GetFullPath(name2));
        }


    }
}
