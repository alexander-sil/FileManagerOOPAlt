﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManagerOOPAlt.Logic
{
    internal class FileLogic
    {
        public void Create(string param)
        {
            File.Create(param).Dispose();

        }

        public void Copy(string sourceFile, string destDir)
        {
            if (File.Exists(Path.GetFullPath(sourceFile)))
            {
                if (Directory.Exists(destDir))
                {
                    File.Create(Path.Combine(destDir, sourceFile)).Dispose(); File.Copy(sourceFile, Path.Combine(destDir, sourceFile));
                }

            }
        }

        public void Delete(string param)
        {
            if (File.Exists(param))
                File.Delete(param);
        }

        public void Move(string sourceFile, string destDir)
        {
            if (File.Exists(sourceFile))
            {
                if (Directory.Exists(destDir))
                {
                    File.Create(Path.Combine(destDir, sourceFile)).Dispose(); File.Copy(sourceFile, Path.Combine(destDir, sourceFile), true);
                    File.Delete(Path.GetFullPath(sourceFile));
                }
            }
        }
    }
}
