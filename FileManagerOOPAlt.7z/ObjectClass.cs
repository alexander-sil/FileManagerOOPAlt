﻿using FileManagerOOPAlt.Logic;
using System;

namespace FileManagerOOPAlt
{
    internal static class ObjectClass
	{
		internal static DirectoryLogic directoryLogic = new DirectoryLogic(); 
		internal static FileLogic fileLogic = new FileLogic(); 
		internal static WindowLogic drawLogic = new WindowLogic();
		internal static MainLogic mainLogic = new MainLogic();
	}
}