﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManagerOOPAlt.Entries
{
    public class DirectoryEntry : Entry
    {
        public DirectoryEntry(DirectoryInfo info)
        {
            Reference = info;

            Size = ObjectClass.directoryLogic.GetSize(info.FullName);

            Name = info.FullName;

            Attributes = info.Attributes;

            LastWriteTime = info.LastWriteTime;

            CreationTime = info.CreationTime;
        }

        public override FileSystemInfo Reference { get; set; }

        public override string Name { get; set; }

        public long Size { get; set; }

        public override FileAttributes Attributes { get; set; }

        public override DateTime LastWriteTime { get; set; }

        public override DateTime CreationTime { get; set; }

    }
}
